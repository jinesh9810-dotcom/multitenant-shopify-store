"use client";

import { useEffect, useState } from "react";
import api from "../../utils/api";
import StatsCard from "../../components/StatsCard";
import OrdersChart from "../../components/OrdersChart";

export default function Dashboard() {
  const [metrics, setMetrics] = useState(null);

  useEffect(() => {
    api.get("/metrics").then((res) => {
      setMetrics(res.data);
    });
  }, []);

  if (!metrics) return <p>Loading dashboard...</p>;

  return (
    <div style={{ padding: 40 }}>
      <h1>Shopify Insights Dashboard</h1>

      <div style={{ display: "flex", gap: 20, marginTop: 30 }}>
        <StatsCard title="Total Customers" value={metrics.totalCustomers} />
        <StatsCard title="Total Orders" value={metrics.totalOrders} />
        <StatsCard title="Total Revenue" value={`₹ ${metrics.revenue}`} />
      </div>

      <h2 style={{ marginTop: 50 }}>Revenue Trend</h2>
      <OrdersChart />

      <h2 style={{ marginTop: 50 }}>Top Customers</h2>

      {metrics.topCustomers.map((c) => (
        <div
          key={c.id}
          style={{
            marginBottom: 10,
            padding: 10,
            border: "1px solid #ccc",
            width: 350
          }}
        >
          {c.email} — ₹{c.totalSpent}
        </div>
      ))}
    </div>
  );
}
